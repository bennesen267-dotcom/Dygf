# Quick Loot (Fabric 1.21.11)
Adds **Take All** and **Drop All** buttons to the right of chest, barrel, ender chest, shulker box, hopper, dispenser and dropper screens.
- Take All: shift-clicks everything into your inventory, swords first, then armor, tools, rest.
- Drop All: throws every stack out of the container.
Client-side only, works on servers.

## Build
Copy `gradle/` wrapper + `gradlew` from the official Fabric example mod (or run `gradle wrapper`), then `./gradlew build`. Jar: `build/libs/`.
Versions: https://fabricmc.net/develop (edit `gradle.properties` if a version is missing).
