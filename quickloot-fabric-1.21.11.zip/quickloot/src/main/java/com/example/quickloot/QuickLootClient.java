package com.example.quickloot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.*;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class QuickLootClient implements ClientModInitializer {

    private static final int GUI_WIDTH = 176;
    private static final int BTN_W = 70;
    private static final int BTN_H = 20;

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof HandledScreen<?> hs)) return;
            ScreenHandler handler = hs.getScreenHandler();

            int guiHeight;
            if (screen instanceof GenericContainerScreen) {
                // chest, barrel(generic), ender chest, shulker is separate below
                guiHeight = 114 + ((handler.slots.size() - 36) / 9) * 18;
            } else if (screen instanceof ShulkerBoxScreen) {
                guiHeight = 166;
            } else if (screen instanceof HopperScreen) {
                guiHeight = 133;
            } else if (screen instanceof Generic3x3ContainerScreen) {
                guiHeight = 166;
            } else {
                return;
            }

            int x = (scaledWidth - GUI_WIDTH) / 2 + GUI_WIDTH + 4;
            int y = (scaledHeight - guiHeight) / 2;

            Screens.getButtons(screen).add(
                ButtonWidget.builder(Text.translatable("quickloot.take_all"), b -> takeAll(handler))
                    .dimensions(x, y, BTN_W, BTN_H).build());
            Screens.getButtons(screen).add(
                ButtonWidget.builder(Text.translatable("quickloot.drop_all"), b -> dropAll(handler))
                    .dimensions(x, y + BTN_H + 2, BTN_W, BTN_H).build());
        });
    }

    /** Container slots only (everything that is not the player's inventory). */
    private static List<Slot> containerSlots(ScreenHandler handler) {
        List<Slot> list = new ArrayList<>();
        for (Slot s : handler.slots) {
            if (!(s.inventory instanceof PlayerInventory) && s.hasStack()) list.add(s);
        }
        return list;
    }

    /** Lower = taken first: swords, armor, tools, then everything else. */
    private static int priority(ItemStack st) {
        if (st.isIn(ItemTags.SWORDS)) return 0;
        if (st.isIn(ItemTags.HEAD_ARMOR) || st.isIn(ItemTags.CHEST_ARMOR)
                || st.isIn(ItemTags.LEG_ARMOR) || st.isIn(ItemTags.FOOT_ARMOR)) return 1;
        if (st.isIn(ItemTags.PICKAXES) || st.isIn(ItemTags.AXES)
                || st.isIn(ItemTags.SHOVELS) || st.isIn(ItemTags.HOES)) return 2;
        return 3;
    }

    private static void takeAll(ScreenHandler handler) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;
        List<Slot> slots = containerSlots(handler);
        slots.sort(Comparator.comparingInt(s -> priority(s.getStack())));
        for (Slot s : slots) {
            if (!s.hasStack()) continue;
            // Shift-click: moves as much as fits into the inventory
            mc.interactionManager.clickSlot(handler.syncId, s.id, 0, SlotActionType.QUICK_MOVE, mc.player);
        }
    }

    private static void dropAll(ScreenHandler handler) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;
        for (Slot s : containerSlots(handler)) {
            if (!s.hasStack()) continue;
            // THROW with button 1 = drop the whole stack (Ctrl+Q)
            mc.interactionManager.clickSlot(handler.syncId, s.id, 1, SlotActionType.THROW, mc.player);
        }
    }
}
